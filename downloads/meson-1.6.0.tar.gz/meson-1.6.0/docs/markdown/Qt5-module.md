# Qt5 module

The Qt5 module provides tools to automatically deal with the various
tools and steps required for Qt.

{{ _include_qt_base.md }}
