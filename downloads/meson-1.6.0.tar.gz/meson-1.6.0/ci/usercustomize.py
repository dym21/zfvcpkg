# SPDX-License-Identifier: Apache-2.0
# Copyright 2021 The Meson development team

import coverage
coverage.process_startup()
