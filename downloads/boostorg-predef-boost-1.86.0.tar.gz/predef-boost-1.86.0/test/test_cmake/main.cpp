/*
Copyright Mike Dev 2018
Copyright 2018 Rene Rivera
Distributed under the Boost Software License, Version 1.0.
See accompanying file LICENSE_1_0.txt or copy at
http://www.boost.org/LICENSE_1_0.txt
*/

/*
Dummy executable, just to make sure that we can find the Boost Predef header
files.
*/

#include <boost/predef.h>

int main()
{
    return 0;
}
