//  Copyright 2020 Andrey Semashev

//  Distributed under the Boost Software License, Version 1.0.
//  See http://www.boost.org/LICENSE_1_0.txt

//  See library home page at http://www.boost.org/libs/filesystem

#if !defined(_WIN32_WCE)
#error "This is not Windows CE"
#endif

int main()
{
}
