/*=============================================================================
    Boost.Wave: A Standard compliant C++ preprocessor library
    http://www.boost.org/

    Copyright (c) 2001-2012 Hartmut Kaiser. Distributed under the Boost
    Software License, Version 1.0. (See accompanying file
    LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
=============================================================================*/

#if 0
    //
    //  some comment
    //
#endif

  // another comment
  // ----------------------------------------------------
1
//R #line 18 "t_9_002.cpp"
//R 1

//H 10: t_9_002.cpp(10): #if
//H 11: t_9_002.cpp(10): #if 0: 0
