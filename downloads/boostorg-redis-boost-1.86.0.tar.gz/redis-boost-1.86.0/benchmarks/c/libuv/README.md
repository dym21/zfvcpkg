This example was taken from

   https://github.com/libuv/libuv/tree/v1.x/docs/code/tcp-echo-server

To build it run, for example

   $ gcc echo_server_direct.c -luv -O2 -o echo_server_direct
