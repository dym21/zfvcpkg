
$ npm install

$ node echo_server_over_redis.js
