.. Copyright 2018 Paul Fultz II
   Distributed under the Boost Software License, Version 1.0.
   (http://www.boost.org/LICENSE_1_0.txt)

Utilities
=========

.. toctree::
    :maxdepth: 1
    
    ../../include/boost/hof/apply
    ../../include/boost/hof/apply_eval
    ../../include/boost/hof/eval
    ../../include/boost/hof/function
    ../../include/boost/hof/lambda
    ../../include/boost/hof/lift
    ../../include/boost/hof/pack
    ../../include/boost/hof/returns
    ../../include/boost/hof/tap
