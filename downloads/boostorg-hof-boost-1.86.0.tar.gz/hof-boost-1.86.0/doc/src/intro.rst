.. Copyright 2018 Paul Fultz II
   Distributed under the Boost Software License, Version 1.0.
   (http://www.boost.org/LICENSE_1_0.txt)

Introduction
============

.. toctree::
    :maxdepth: 2

    index
    building
    gettingstarted
    examples
    point_free
