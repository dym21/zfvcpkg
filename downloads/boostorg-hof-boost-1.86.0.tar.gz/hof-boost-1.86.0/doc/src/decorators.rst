.. Copyright 2018 Paul Fultz II
   Distributed under the Boost Software License, Version 1.0.
   (http://www.boost.org/LICENSE_1_0.txt)

Decorators
==========

.. toctree::
    :maxdepth: 1

    ../../include/boost/hof/capture
    ../../include/boost/hof/if
    ../../include/boost/hof/limit
    ../../include/boost/hof/repeat
    ../../include/boost/hof/repeat_while