.. Copyright 2018 Paul Fultz II
   Distributed under the Boost Software License, Version 1.0.
   (http://www.boost.org/LICENSE_1_0.txt)

.. _contents:

Boost.HOF
=========

**Paul Fultz II**

.. toctree::
    :maxdepth: 3

    src/intro
    src/overview
    src/reference

    src/configurations
    src/discussion
    src/acknowledgements
    src/license

