Release history
===============

LibTIFF releases.

.. toctree::
    :maxdepth: 1
    :titlesonly:

    v4.7.0
    v4.6.0
    v4.5.1
    v4.5.0
    v4.4.0
    v4.3.0
    v4.2.0
    v4.1.0
    v4.0.10
    v4.0.9
    v4.0.8
    v4.0.7
    v4.0.6
    v4.0.5
    v4.0.4
    v4.0.4beta
    v4.0.3
    v4.0.2
    v4.0.1
    v4.0.0
    historical
