#ifndef XML_STRING_H_PRIVATE__
#define XML_STRING_H_PRIVATE__

#include <libxml/xmlstring.h>

XML_HIDDEN xmlChar *
xmlEscapeFormatString(xmlChar **msg);

#endif /* XML_STRING_H_PRIVATE__ */
