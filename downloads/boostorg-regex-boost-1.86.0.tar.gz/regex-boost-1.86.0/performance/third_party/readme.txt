Place third party headers and libraries in this directory to have them built as part of the performance test application.

Or install in your compiler's search paths if you prefer.