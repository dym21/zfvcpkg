// Boost.Bimap
//
// Copyright (c) 2006-2007 Matias Capeletto
// Copyright (c) 2024 Joaquin M Lopez Munoz
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

//  VC++ 8.0 warns on usage of certain Standard Library and API functions that
//  can be cause buffer overruns or other possible security issues if misused.
//  See https://web.archive.org/web/20071014014301/http://msdn.microsoft.com/msdnmag/issues/05/05/SafeCandC/default.aspx
//  But the wording of the warning is misleading and unsettling, there are no
//  portable alternative functions, and VC++ 8.0's own libraries use the
//  functions in question. So turn off the warnings.
#define _CRT_SECURE_NO_DEPRECATE
#define _SCL_SECURE_NO_DEPRECATE

#include <boost/config.hpp>

#include <boost/core/ignore_unused.hpp>
#include <boost/core/lightweight_test.hpp>

// Boost.Bimap
#include <boost/bimap/support/lambda.hpp>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/unordered_set_of.hpp>
#include <boost/bimap/list_of.hpp>
#include <boost/bimap/vector_of.hpp>
#include <boost/bimap/unconstrained_set_of.hpp>

#include <libs/bimap/test/strong_type.hpp>

void test_bimap_operator_bracket()
{
    using namespace boost::bimaps;

    // Simple test
    {
        typedef bimap< int, std::string > bm;

        bm b;
        b.insert( bm::value_type(0,"0") );
        b.insert( bm::value_type(1,"1") );
        b.insert( bm::value_type(2,"2") );
        b.insert( bm::value_type(3,"3") );

        BOOST_TEST( b.left.at(1) == "1" );

        // Out of range test
        {
            bool value_not_found_test_passed = false;
            b.clear();
            try
            {
                bool comp;
                comp = b.left.at(2) < "banana";
                boost::ignore_unused(comp);
            }
            catch( std::out_of_range & )
            {
                value_not_found_test_passed = true;
            }

            BOOST_TEST( value_not_found_test_passed );
        }
    }

    // Mutable data test (1)
    {
        typedef bimap<int, list_of<std::string> > bm;
        bm b;

        // Out of range test
        {
            bool value_not_found_test_passed = false;
            b.clear();
            try
            {
                bool comp;
                comp = b.left.at(1) < "banana";
                boost::ignore_unused(comp);
            }
            catch( std::out_of_range & )
            {
                value_not_found_test_passed = true;
            }

            BOOST_TEST( value_not_found_test_passed );

        }

        // Out of range test (const version)
        {
            bool value_not_found_test_passed = false;
            b.clear();
            try
            {
                const bm & cb(b);
                bool comp;
                comp = cb.left.at(1) < "banana";
                boost::ignore_unused(comp);
            }
            catch( std::out_of_range & )
            {
                value_not_found_test_passed = true;
            }

            BOOST_TEST( value_not_found_test_passed );
        }

        BOOST_TEST( b.left[1]    == "" );
        BOOST_TEST( b.left.at(1) == "" );
        b.left[2] = "two";
        BOOST_TEST( b.left.at(2) == "two" );
        b.left[2] = "<<two>>";
        BOOST_TEST( b.left.at(2) == "<<two>>" );
        b.left.at(2) = "two";
        BOOST_TEST( b.left.at(2) == "two" );

    }

    // Mutable data test (2)
    {
        typedef bimap< vector_of<int>, unordered_set_of<std::string> > bm;
        bm b;

        // Out of range test
        {
            bool value_not_found_test_passed = false;
            b.clear();
            try
            {
                bool comp;
                comp = b.right.at("banana") < 1;
                boost::ignore_unused(comp);
            }
            catch( std::out_of_range & )
            {
                value_not_found_test_passed = true;
            }
            BOOST_TEST( value_not_found_test_passed );
        }

        // Out of range test (const version)
        {
            bool value_not_found_test_passed = false;
            b.clear();
            try
            {
                const bm & cb(b);
                bool comp;
                comp = cb.right.at("banana") < 1;
                boost::ignore_unused(comp);
            }
            catch( std::out_of_range & )
            {
                value_not_found_test_passed = true;
            }

            BOOST_TEST( value_not_found_test_passed );
        }

        b.right["one"];
        BOOST_TEST( b.size() == 1 );
        b.right["two"] = 2;
        BOOST_TEST( b.right.at("two") == 2 );
        b.right["two"] = -2;
        BOOST_TEST( b.right.at("two") == -2 );
        b.right.at("two") = 2;
        BOOST_TEST( b.right.at("two") == 2 );
    }

    // Mutable data test (3)
    {
        typedef bimap< unconstrained_set_of<int>,
                       unordered_set_of<std::string>,
                       right_based                       > bm;

        bm b;

        b.right["one"];
        BOOST_TEST( b.size() == 1 );
        b.right["two"] = 2;
        BOOST_TEST( b.right.at("two") == 2 );
        b.right["two"] = -2;
        BOOST_TEST( b.right.at("two") == -2 );
        b.right.at("two") = 2;
        BOOST_TEST( b.right.at("two") == 2 );
    }

    // Heterogeneous access test (1)
    {
        typedef bimap
        <
          set_of<int, std::less< strong<int> > >,
          list_of<std::string>                    
        > bm;

        bm b;

        b.left[1] = "0";
        b.left[semistrong<int>(1)] = "1";
        BOOST_TEST( b.left.at(strong<int>(1)) == "1");
        b.left.at(strong<int>(1)) = "2";
        BOOST_TEST( b.left.at(strong<int>(1)) == "2");
    }

    // Heterogeneous access test (2)
    {
        typedef bimap
        <
          list_of<int>,
          unordered_set_of
          <
            std::string,
            boost::hash< strong<std::string> >,
            std::equal_to< strong<std::string> >
          >
        > bm;

        bm b;

        b.right["1"]=0;
        b.right[semistrong<std::string>("1")] = 1;
        BOOST_TEST( b.right.at(strong<std::string>("1")) == 1);
        b.right.at(strong<std::string>("1")) = 2;
        BOOST_TEST( b.right.at(strong<std::string>("1")) == 2);
    }
}

int main()
{
    test_bimap_operator_bracket();

    return boost::report_errors();
}

