// Copyright 2023 Peter Dimov
// Distributed under the Boost Software License, Version 1.0.
// https://www.boost.org/LICENSE_1_0.txt

#define _SILENCE_CXX17_C_HEADER_DEPRECATION_WARNING

#include <complex.h>
#include <boost/mp11.hpp>

int main()
{
}
