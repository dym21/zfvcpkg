var searchData=
[
  ['bracket',['bracket',['../structbracket.html',1,'']]]
];
