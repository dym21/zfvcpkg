var searchData=
[
  ['data',['data',['../struct_d_a_t_a___t_y_p_e.html#ae644cc131b810b459261b3426e2c459c',1,'DATA_TYPE']]]
];
