## Instructions for Documentation

Scripts to build the documentation can be found at https://github.com/boostorg/release-tools/tree/master/build_docs

For example on a Linux system, copy the file `linuxdocs.sh` into the current directory and run it.

```
./linuxdocs.sh
```

The quickbook doc files are compiled into html format.
