#include <boost/json.hpp>
#include <iostream>


int main()
{
    std::cout << boost::json::value() << '\n';
}
