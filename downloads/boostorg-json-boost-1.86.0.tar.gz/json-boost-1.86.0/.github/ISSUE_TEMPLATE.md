PLEASE DON'T FORGET TO "STAR" THIS REPOSITORY :)

When reporting a bug please include the following:

### Version of Boost

You can find the version number in the file `<boost/version.hpp>`

### Steps necessary to reproduce the problem

A small compiling program is the best. If your code is
public, you can provide a link to the repository.

### All relevant compiler information

If you are unable to compile please include the type and
version of compiler you are using as well as all compiler
output including the error message, file, and line numbers
involved.

The more information you provide the sooner your issue
can get resolved!
