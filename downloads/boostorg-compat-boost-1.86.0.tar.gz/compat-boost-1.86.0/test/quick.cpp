// Copyright 2023 Peter Dimov.
// Distributed under the Boost Software License, Version 1.0.
// https://www.boost.org/LICENSE_1_0.txt

#include <boost/compat/latch.hpp>
#include <boost/compat/shared_lock.hpp>
#include <boost/compat/invoke.hpp>
#include <boost/compat/bind_front.hpp>
#include <boost/compat/bind_back.hpp>

int main()
{
}
