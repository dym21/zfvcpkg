//////////////////////////////////////////////////////////////////////////////
// c_traits.cpp
//
//  (C) Copyright Eric Niebler 2004.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

/*
 Revision history:
   6 January 2006 : Initial version.
*/

#define BOOST_XPRESSIVE_USE_C_TRAITS
#define BOOST_XPRESSIVE_TEST_WREGEX
#include "./regress.ipp"

