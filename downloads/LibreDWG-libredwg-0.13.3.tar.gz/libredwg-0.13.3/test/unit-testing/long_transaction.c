#define DWG_TYPE DWG_TYPE_LONG_TRANSACTION
#include "common.c"

void
api_process (dwg_object *obj)
{
  int error;
  dwg_obj_long_transaction *_obj = dwg_object_to_LONG_TRANSACTION (obj);
}
