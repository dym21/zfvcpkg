# Security Policy

## Supported Versions

The last 2 releases.

## Reporting a Vulnerability

Report a vulnerability by email to the maintainer.
