<!-- SPDX-License-Identifier: BSD-3-Clause -->
<!-- Copyright (c) Contributors to the OpenEXR Project -->

This is a list of contributors to the OpenEXR project, sorted
alphabetically by first name.

If you know of missing, please email info@openexr.com or submit a PR.
  
* Aaron Demolder
* Abe Fettig
* Aloys Baillet
* Andre Mazzone
* Andrew Kunz
* Anton Dukhovnikov
* Antonio Rojas
* Aras Pranckevičius
* Arkady Shapkin
* Arkell Rasiah
* Axel Waggershauser
* Balázs Oroszi
* Barnaby Robson
* Ben Grimes
* Brendan Bolles
* Cary Phillips
* Chris Leu
* Christina Tempelaar-Lietz
* Christopher Horvath
* Christopher Kulla
* Christoph Gohlke
* Cristian Martínez
* Dan Horák
* Daniel Kaneider
* Darby Johnston
* Dave Sawyer
* David Korczynski
* Diogo Teles Sant'Anna
* Dirk Lemstra
* Drew Hess
* Ed Hanway
* Edward Kmett
* Eric Sommerlade
* Eric Wimmer
* E Sommerlade
* Florian Kainz
* Grant Kim
* Gregorio Litenstein
* Gyula Gubacsi
* Halfdan Ingvarsson
* Harry Mallon
* Huibean Luo
* Ibraheem Alhashim
* Jack Kingsman
* Jamie Kenyon
* Jan Tojnar
* Jean-Francois Panisset
* Jens Lindgren
* Ji Hun Yu
* Johannes Vollmer
* John Loy
* John Mertic
* Jonathan Stone
* Jose Luis Cercos-Pita
* Joseph Goldstone
* Juha Reunanen
* Julian Amann
* Juri Abramov
* Karl Hendrikse
* Karl Rasche
* Kevin Wheatley
* Kimball Thurston
* Larry Gritz
* Laurens Voerman
* L. E. Segovia
* Liam Fernandez
* Lucy Wilkes
* Mark Reid
* Mark Sisson
* Martin Aumüller
* Martin Husemann
* Matthäus G. Chajdas
* Matthias C. M. Troffaes
* Matt Pharr
* Md Sadman Chowdhury
* Michael Thomas
* Nicholas Yue
* Nick Porcino
* Nick Rasmussen
* Nicolas Chauvet
* Niklas Hambüchen
* OgreTransporter
* Owen Thompson
* Paul Schneider
* Peter Hillman
* Peter Steneteg
* Peter Urbanec
* Phil Barrett
* Piotr Stanczyk
* Ralph Potter
* Rémi Achard
* Reto Kromer
* Richard Goedeken
* Sergey Fedorov
* Shawn Walker-Salas
* Simon Boorer
* Simon Otter
* Srinath Ravichandran
* Thanh Ha
* Thomas Debesse
* Thorsten Kaufmann
* Timothy Lyanguzov
* Wenzel Jakob
* Wojciech Jarosz
* Xo Wang
* Yaakov Selkowitz
* Yining Karl Li
* Yujie Shu
