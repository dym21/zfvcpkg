// Boost.Geometry (aka GGL, Generic Geometry Library) test file
//
// Copyright Barend Gehrels 2010, Geodan, Amsterdam, the Netherlands
// Use, modification and distribution is subject to the Boost Software License,
// Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)



Download shapelib from 
http://shapelib.maptools.org/
or http://download.osgeo.org/shapelib/

and extract to this folder.


Install at least the following files:
- shpopen.c 
- shapefil.h 
- dbfopen.c 

For new shapelibs:
- safileio.c 

