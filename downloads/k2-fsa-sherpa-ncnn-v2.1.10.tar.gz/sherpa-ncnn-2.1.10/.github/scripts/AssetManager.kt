package android.content.res

// a dummy class for testing only
class AssetManager
