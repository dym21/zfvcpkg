# Install kotlin on macOS

Assume that you have installed jdk.

```bash
wget https://github.com/JetBrains/kotlin/releases/download/v1.8.0/kotlin-compiler-1.8.0.zip
unzip kotlin-compiler-1.8.0.zip
export PATH=$PWD/kotlinc/bin:$PATH
```
