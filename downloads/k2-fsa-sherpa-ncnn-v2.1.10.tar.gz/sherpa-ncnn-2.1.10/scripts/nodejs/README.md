# Introduction

Real-time speech-to-text with [Next-gen Kaldi](https://github.com/k2-fsa/).

It processes everything locally without accessing the Internet.

Please refer to
https://github.com/k2-fsa/sherpa-ncnn/tree/master/nodejs-examples
for examples.
