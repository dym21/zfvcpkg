//
//  SherpaNcnnApp.swift
//  SherpaNcnn
//
//  Created by knight on 2023/4/5.
//

import SwiftUI

@main
struct SherpaNcnnApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
