from _sherpa_ncnn import Alsa, Display

from .recognizer import Recognizer
