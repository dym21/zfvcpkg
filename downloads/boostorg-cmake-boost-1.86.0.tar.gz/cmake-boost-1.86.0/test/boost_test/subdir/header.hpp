#ifndef HEADER_HPP_INCLUDED
#define HEADER_HPP_INCLUDED

// Copyright 2023 Peter Dimov
// Distributed under the Boost Software License, Version 1.0.
// https://www.boost.org/LICENSE_1_0.txt

inline int f()
{
    return 0;
}

#endif // #ifndef HEADER_HPP_INCLUDED
