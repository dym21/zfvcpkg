Numeric extension
=================

Overview
--------

*TODO*
