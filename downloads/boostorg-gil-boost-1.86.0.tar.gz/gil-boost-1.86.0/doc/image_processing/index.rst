Image Processing
================

The GIL documentation sections listed below are dedicated to describe the library
features, structures and algorithms, for image processing and analysis.

.. toctree::
   :maxdepth: 2
   :caption: Table of Contents

   overview
   basics
   affine-region-detectors
   contrast_enhancement/index

