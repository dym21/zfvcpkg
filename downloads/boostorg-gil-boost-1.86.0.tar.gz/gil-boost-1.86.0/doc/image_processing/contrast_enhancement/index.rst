Contrast Enhancement
====================

The GIL documentation sections listed below are dedicated to describe image
processing algorithms used for contrast enhancement.

.. toctree::
   :maxdepth: 1
   :caption: Table of Contents

   overview