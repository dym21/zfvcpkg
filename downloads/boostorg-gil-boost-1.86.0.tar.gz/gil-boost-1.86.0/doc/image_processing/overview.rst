Overview
========

Development of the image processing features was initiated during two Boost
projects run in frame of the Google Summer of Code 2019:

- `Image Processing Algorithms <https://github.com/boostorg/gil/projects/5>`_
- `Fundamentals of epipolar geometry <https://github.com/boostorg/gil/projects/6>`_

The image processing features were first released with Boost 1.72.
