.. _stl_compatibility:

STL compatibility
=================

*TODO*