Extensions
==========

The GIL documentation sections listed below are dedicated to describe the
usage of external containers as histograms for GIL images.

.. toctree::
   :maxdepth: 1
   :caption: Table of Contents

   overview
   std
