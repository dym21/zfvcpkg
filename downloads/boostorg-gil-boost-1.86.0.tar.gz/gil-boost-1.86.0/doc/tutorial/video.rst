Tutorial: Video Lecture
=======================

This is original video lecture about GIL presented by Lubomir Bourdev.

.. raw:: html

    <div style="position: relative; overflow: hidden; max-width: 100%; height: auto;">
        <iframe width="800" height="450" src="https://www.youtube.com/embed/sR8Wjg0pceE?rel=0" frameborder="0" allow="autoplay=false; encrypted-media" allowfullscreen></iframe>
    </div>

Source link: https://www.youtube.com/watch?v=sR8Wjg0pceE
