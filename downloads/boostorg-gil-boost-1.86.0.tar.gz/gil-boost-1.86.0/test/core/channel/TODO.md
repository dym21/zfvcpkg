# Channel TODO

Issues and questions related to implementation, testing, etc. of channel:

- Provide algorithm performance overloads for scoped channel and packed channels
- Update concepts and documentation
- What to do about pointer types?!
- Performance!!
- Is channel_convert the same as native?
- Is operator++ on float32_t the same as native? How about if operator++ is defined in scoped_channel to do _value++?
