#include "nscore.h"

#include "../src/Big5Freq.tab"
#include "../src/EUCKRFreq.tab"
#include "../src/EUCTWFreq.tab"
#include "../src/GB2312Freq.tab"
#include "../src/JISFreq.tab"
