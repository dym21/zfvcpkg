.. raw:: html

   <form class="sidebar-search-container top" method="get" action="search.html" role="search">
      <input class="sidebar-search" placeholder="Search" name="q" aria-label="Search">
      <input type="hidden" name="check_keywords" value="yes">
      <input type="hidden" name="area" value="default">
    </form>

    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:20px;">
        <div class="discordLink" style="display:flex;align-items:center;margin-top: -5px;">
            <a href="https://discord.gg/DQjvZ6ERqH" target=_blank>Find <b>#mupdf</b> on <b>Discord</b></a>
            <a href="https://discord.gg/DQjvZ6ERqH" target=_blank><img src="_images/discord-mark-blue.svg" alt="Discord logo" /></a>
        </div>

        <div class="feedbackLink"><a id="feedbackLinkTop" target=_blank>Do you have any feedback on this page?</b></a></div>
    </div>

    <script>

    var url_string = window.location.href;
    var a = document.getElementById('feedbackLinkTop');
    a.setAttribute("href", "https://artifex.com/contributor/feedback.php?utm_source=rtd-mupdf&utm_medium=rtd&utm_content=header-link&="+url_string);

    </script>
