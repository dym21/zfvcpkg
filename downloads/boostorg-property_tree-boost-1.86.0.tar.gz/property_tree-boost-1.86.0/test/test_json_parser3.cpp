#define BOOST_BIND_NO_PLACEHOLDERS
#include <boost/property_tree/json_parser.hpp>

// Must be able to build with BOOST_BIND_NO_PLACEHOLDERS defined
// History: https://github.com/boostorg/property_tree/pull/112#issuecomment-1812867565

int main() {}
