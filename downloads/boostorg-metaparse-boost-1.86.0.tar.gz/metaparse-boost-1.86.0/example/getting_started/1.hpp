#ifndef BOOST_METAPARSE_GETTING_STARTED_1_HPP
#define BOOST_METAPARSE_GETTING_STARTED_1_HPP

// Automatically generated header file

// Definitions of section 

#endif

