#ifndef BOOST_METAPARSE_GETTING_STARTED_2_HPP
#define BOOST_METAPARSE_GETTING_STARTED_2_HPP

// Automatically generated header file

// Definitions before section 1.2.2
#include "1_2_2.hpp"

// Definitions of section 1.2.2

#endif

