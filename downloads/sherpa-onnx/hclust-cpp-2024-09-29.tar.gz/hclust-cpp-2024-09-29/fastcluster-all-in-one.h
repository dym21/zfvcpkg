#ifndef fastclustercpp_all_in_one_H
#define fastclustercpp_all_in_one_H

#include "fastcluster.cpp"

#endif // fastclustercpp_all_in_one_H
