/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// polymorphic_derived2.cpp

// (C) Copyright 2018 Robert Ramey - http://www.rrsd.com .
// Use, modification and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision history.

#define POLYMORPHIC_BASE_IMPORT
#define POLYMORPHIC_DERIVED2_EXPORT
#include "polymorphic_derived2.cpp"
