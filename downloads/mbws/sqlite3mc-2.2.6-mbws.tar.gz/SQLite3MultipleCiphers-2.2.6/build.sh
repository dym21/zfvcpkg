mkdir cmake_build
cd cmake_build && cmake .. && make -j4
