#!/bin/sh

bin_path=$(pwd)/bin
cd ../;make BUILD_TYPE=debug prefix=$bin_path install;make clean;
cd ../;make prefix=$bin_path install;make clean; 


