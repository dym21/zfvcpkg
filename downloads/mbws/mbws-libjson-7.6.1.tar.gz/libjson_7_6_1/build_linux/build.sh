#!/bin/sh

bin_path=$(pwd)/bin
cd ../
make BUILD_TYPE=debug prefix=$bin_path install;make clean;
make prefix=$bin_path install;make clean;


