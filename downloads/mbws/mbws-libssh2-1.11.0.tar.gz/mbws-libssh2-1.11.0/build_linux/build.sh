#!/bin/sh


cd ../../
ssl_path=$(pwd)/zf-gmssl/build_linux/bin
cd -
cd ../;
./buildconf
./configure -enable-shared=no --disable-examples-build --disable-tests --with-libssl-prefix=$ssl_path --prefix=$(pwd)/build_linux/bin LDFLAGS="-lpthread -ldl" CXXFLAGS="-fpic" CFLAGS="-fpic"
make;make install;
