

//#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <time.h>
#include "Zf_log.h"

void
_MY_LOG_Message_SM(char *msg)   //˽�п�log
{
	int size;
	FILE *fp=NULL;
	FILE *f=NULL;
    time_t rawtime;
    struct tm  *timeinfo;
    f = fopen("/tmp/zfusbkeydebug/SM2.log","a+");
    if(f == NULL){
        return;
    }
    time ( &rawtime );
    timeinfo = localtime ( &rawtime );
    fprintf (f, "%04d-%02d-%02d %02d:%02d:%02d\n", timeinfo->tm_year + 1900,timeinfo->tm_mon+1,
             timeinfo->tm_mday, timeinfo->tm_hour,timeinfo->tm_min,timeinfo->tm_sec );
    
	time ( &rawtime );
	fprintf(f,"     ");
	fprintf(f,"%s\n",msg);
	if (f!=NULL)
	{
		fclose(f);
		f=NULL;
	}
    fp = fopen("/tmp/zfusbkeydebug/SM2.log","a+");
    if(fp == NULL){
        return;
    }
	fseek(fp,0,SEEK_END);
	size=ftell(fp);
	fclose(fp);
	fp=NULL;
	if (size>1024*1024*100) 
	{
		remove("/tmp/zfusbkeydebug/SM2.log");
	}
	///////////////////////////
	return;

}

void
_MY_LOG_Message_Bin_SM(
					unsigned char *msgBin,
					unsigned int msgBinLen)
{
    FILE *f=NULL;
    unsigned int i=0,j=0;
    f = fopen("/tmp/zfusbkeydebug/SM2.log","a+");
    if(f == NULL){
        return;
    }
    
	fprintf(f,"            ");
	j = 0;
	for(i=0;i<msgBinLen;i++){
		fprintf(f,"%02X ",msgBin[i]);
		j++;
		if(j >= 16){
			fprintf(f,"\n");
			fprintf(f,"            "); 
			j = 0;
		}
	}
	fprintf(f,"\n");
	fclose(f);
	f=NULL;
	return;
}

