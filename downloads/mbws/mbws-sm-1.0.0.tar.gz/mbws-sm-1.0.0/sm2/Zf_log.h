#ifndef _LOG_H_
#define _LOG_H_

#define _DEBUG_VERSION

#ifdef  __cplusplus
extern "C" {
#endif


#if defined(_DEBUG_VERSION)
#define _MY_DEBUG_MESSAGE_SM(s)           _MY_LOG_Message_SM(s)
#define _MY_DEBUG_MESSAGE_BIN_SM(s1,s2)   _MY_LOG_Message_Bin_SM(s1,s2)
#else
#define _MY_DEBUG_MESSAGE_SM(s)
#define _MY_DEBUG_MESSAGE_BIN_SM(s1,s2)
#endif


extern void
_MY_LOG_Message_SM(char *msg);

extern void
_MY_LOG_Message_Bin_SM(
    unsigned char *msgBin,
    unsigned int msgBinLen);

#ifdef  __cplusplus
}
#endif

#endif