/***************************************************************************
* File name    :	SM3c.c
* Function     :	SM3 function
* Author       : 	 
* Date         :	2011/03/ 
* Version      :    v1.0
* Description  :     
* ModifyRecord :
****************************************************************************/
#include <memory.h>
#include <stdio.h>
#include "sm3.h"

static void SM3Transform(UINT32 stateIV[8], UINT32 T[64], UINT8 block[64]);
static void Extend(UINT32 *output,UINT32 *output1,UINT32 *input,UINT32 len);
static void Encode(UINT8 *output,UINT32 *input,UINT32 len);
static void Decode(UINT32 *output,UINT8 *input,UINT32 len);


static UINT8 PADDING[64] = {
  0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};


/* ROTATE_LEFT rotates x left n bits. 
*/
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/*Substi_P0,Substi_P1,Bool_FF and Bool_GG are basic SM3 functions.
*/
#define Substi_P0(x) ((x) ^ ROTATE_LEFT((x), 9) ^ ROTATE_LEFT((x), 17))
#define Substi_P1(x) ((x) ^ ROTATE_LEFT((x), 15) ^ ROTATE_LEFT((x), 23))
#define Bool_FF(x, y, z, j) ((j) < 16) ? ((x) ^ (y) ^ (z)) : (((x) & (y)) | ((x) & (z)) | ((y) & (z)))
#define Bool_GG(x, y, z, j) ((j) < 16) ? ((x) ^ (y) ^ (z)) : ((x) & (y) | ((0xffffffff^x) & (z)))

/* SS1,SS2,TT1 and TT2 are the transform functions for the SM3 algorithm,
be using to generate intervening variables ss1,ss2,tt1,tt2.
 
#define SS1(a, b, t, j) {\
        UINT32 s1 = ROTATE_LEFT(a, 12) + b + ROTATE_LEFT(t, j);\
        s1 = ROTATE_LEFT(s1, 7);\
        return s1;\
    }
#define SS2(a, b) {\
        (UINT32) s2 = a ^ ROTATE_LEFT(b, 12);\
        return s2;\
    }
#define TT1(a, b, c, d, x, w1, j) {\
        (UINT32) t1 = Bool_FF(a, b, c, j) + d + x + w1[j];\
        return t1;\
    }
#define TT2(a, b, c, d, x, w, j) {\
        (UINT32) t2 = Bool_GG(a, b, c, j) + d + x + w[j];\
        return t2;\
    }
*/



/***************************************************************************
* Subroutine:	SM3_Init
* Function:		SM3 initialization. Begins an SM3 operation, writing a new context.
* Input:		context-SM3 Context struct
* Output:		None;
* Description:	 
* Date:			2011.03. 
* ModifyRecord:
* *************************************************************************/ 
void SM3_Init (SM3_CONTEXT *context)
{

  UINT16 j;
  context->count[0] = context->count[1] = 0;

  /* Load magic initialization constants.
   */
  context->stateIV[0] = 0x7380166f;
  context->stateIV[1] = 0x4914b2b9;
  context->stateIV[2] = 0x172442d7;
  context->stateIV[3] = 0xda8a0600;
  context->stateIV[4] = 0xa96f30bc;
  context->stateIV[5] = 0x163138aa;
  context->stateIV[6] = 0xe38dee4d;
  context->stateIV[7] = 0xb0fb0e4e;
  /* Load initial constant list T. 
   */
  for ( j=0;j<=15;j++)
  {
  	context->T[j]=0x79cc4519;
  }  
  for(j=16;j<=63;j++)
  {
  	context->T[j]=0x7a879d8a;
  }  
}


/***************************************************************************
* Subroutine:	SM3_Update
* Function:		SM3 block update operation. Continues an SM3 message-digest
	 operation, processing another message block, and updating the
	 context
* Input:		context-SM3 Context struct
                input- the data will hash
                inputLen- the data length
* Output:		None;
* Description:	 
* Date:			2011.03. 
* ModifyRecord:
* *************************************************************************/ 
void SM3_Update(
SM3_CONTEXT *context,              /* context */
UINT8 *input,           /* input block */
UINT32 inputLen)          /* length of input block */
{
	UINT32 i, index, partLen;

	/* Compute number of bytes mod 64 */
	index = (UINT32)((context->count[0] >> 3) & 0x3F);

	/* Update number of bits */
	if((context->count[0] += ((UINT32)inputLen << 3)) < ((UINT32)inputLen << 3))
		context->count[1]++;

	context->count[1] += ((UINT32)inputLen >> 29);

	partLen = 64 - index;

	/* Transform as many times as possible.
	 */
	if(inputLen >= partLen) {
		memcpy(&context->buffer[index], input, partLen);
		SM3Transform(context->stateIV, context->T, context->buffer);

		for(i = partLen; i + 63 < inputLen; i += 64)
			SM3Transform(context->stateIV, context->T,&input[i]);

    index = 0;
  }
  else
    i = 0;

	/* Buffer remaining input */
	memcpy(&context->buffer[index], &input[i], inputLen-i);
}


/***************************************************************************
* Subroutine:	SM3_Final
* Function:		SM3 finalization. Ends an SM3 message-digest operation, writing the
	 the message digest and zeroizing the context. 
* Input:		context-SM3 Context struct
* Output:		digest- the message digest;
* Description:	 
* Date:			2011.03. 
* ModifyRecord:
* *************************************************************************/ 
void SM3_Final (
SM3_CONTEXT *context,               /* context */
UINT32 digest[8])       /* message digest */

{
	UINT8 bits[8];
	UINT32 index, padLen;

	/* Save number of bits */
	Encode(bits, context->count, 8);

	/* Pad out to 56 mod 64.
	 */
	index = (UINT32)((context->count[0] >> 3) & 0x3f);
	padLen = (index < 56) ? (56 - index) : (120 - index);
	SM3_Update(context, PADDING, padLen);

	/* Append length (before padding) */
	SM3_Update(context, bits, 8);

	/* Store state in digest */
	//Encode(digest, context->stateIV, 32);
    //�������
	memcpy(digest,context->stateIV,32);
	/* Zeroize sensitive information. */

	memset(context, 0, sizeof(*context));
}


/***************************************************************************
* Subroutine:	SM3Transform
* Function:		SM3 basic transformation. Transforms state based on block. 
* Input:		None
* Output:		None;
* Description:	 
* Date:			2011.03. 
* ModifyRecord:
* *************************************************************************/ 
void  SM3Transform (UINT32 stateIV[8],UINT32 T[64],UINT8 block[64])
{
    UINT32 i=0,j=0,n=0;
    UINT32 ss1=0, ss2=0, tt1=0, tt2=0, w[16]={0}, w0[68]={0}, w1[64]={0};
	UINT32 a = stateIV[0], b = stateIV[1], c = stateIV[2], d = stateIV[3], 
		e = stateIV[4], f = stateIV[5], g = stateIV[6], h = stateIV[7] ;
	
    ///////////////////////////////
	//BY GaoYang 
	int imy=0;
	UINT32 uimyBF=0;
	UINT32 uimyGG=0;
	UINT32 uimyTemp1=0;
	UINT32 uimyTemp2=0;
	UINT32 uimyTemp3=0;

	///////////////////////////////
	Decode(w, block, 64);
// 	printf("\n��Ϣ���ֳ�16������:\n");
// 	for(imy=0;imy<16;imy++)
// 	{
// 		printf("w[%2d] = %4x ",imy,w[imy]);
// 		if(imy%4==0&&imy!=0)
// 			printf("\n");
// 	}
	Extend(w0, w1, w, 16);
    ///////////////////////////////
	//BY GaoYang
	//��ӡ�м�����
// 	printf("\n��չ�����ϢW0 W1...W67\n");
// 	for(imy=0;imy<68;imy++)
// 	{
// 		printf("w0[%2d] = %4x ",imy,w0[imy]);
// 		if(imy%4==0&&imy!=0)
// 			printf("\n");
// 	}
// 	printf("\n");
// 	printf("\n��չ�����ϢW10 W11...W163\n");
// 	for(imy=0;imy<64;imy++)
// 	{
// 		printf("w1[%2d] = %4x ",imy,w1[imy]);
// 		if(imy%4==0&&imy!=0)
// 			printf("\n");
// 	}
// 	printf("\n");
	/* Begin compressing.*/
	n = (sizeof(w)<<3)>>9;
	for(i = 0; i < n; i++)
	{
		////////////////////////////
// 		printf("	A	B	C	D	E	F	G	H");
// 	    printf("\n");
// 		printf("  %x %x %x %x %x %x %x %x",a,b,c,d,e,f,g,h);
// 		printf("\n");
		////////////////////////////
        for(j = 0; j < 64; j++)
		{
			uimyTemp1 = ROTATE_LEFT(a, 12);
			uimyTemp2 = ROTATE_LEFT(T[j], j);

            ss1 = uimyTemp1 + e + uimyTemp2;

            ss1 = ROTATE_LEFT(ss1, 7);
			
			uimyTemp3 = ROTATE_LEFT(a, 12);
            ss2 = ss1 ^ uimyTemp3;

			uimyBF = Bool_FF(a, b, c, j);

            tt1 = uimyBF + d + ss2 + w1[j];

			uimyGG = Bool_GG(e, f, g, j);
	

            tt2 = uimyGG + h + ss1 + w0[j];

            d = c;
            c = ROTATE_LEFT(b, 9);
            b = a;
            a = tt1;
            h = g;
            g = ROTATE_LEFT(f,19);
            f = e;
            e = Substi_P0(tt2);
			////////////////////////////
// 			printf("j	A	B	C	D	E	F	G	H");
// 			printf("\n");
// 			printf("%d %x %x %x %x %x %x %x %x",j,a,b,c,d,e,f,g,h);
// 			printf("\n");
			////////////////////////////
		}

		stateIV[0] = a ^ stateIV[0];
		stateIV[1] = b ^ stateIV[1];
		stateIV[2] = c ^ stateIV[2];
		stateIV[3] = d ^ stateIV[3];
		stateIV[4] = e ^ stateIV[4];
		stateIV[5] = f ^ stateIV[5];
		stateIV[6] = g ^ stateIV[6];
		stateIV[7] = h ^ stateIV[7];
	}
	
	
	/* Zeroize sensitive information. */
	
	memset(w, 0, sizeof(w));
}



/***************************************************************************
* Subroutine:	Extend
* Function:		Extend input (UINT32) into output and ouput1 (UINT32). Assumes len is
	 a multiple of 4..
* Input:		None
* Output:		None;
* Description:	 
* Date:			2011.03. 
* ModifyRecord:
* *************************************************************************/ 
void Extend(UINT32 *output,UINT32 *output1,UINT32 *input,UINT32 len)
{
   UINT32 i=0, j=0;
   ////////////////
   UINT32 uiTemp1=0;
   UINT32 uiTemp2=0;
   UINT32 uiTemp3=0;
   UINT32 uiTemp4=0;
   ////////////////
   for(j = 0; j < len; j++){
        output[j]=input[j];
    }

    /*for(j = len; j < 68; j++){
        output[j] = Substi_P1((output[j-len]) ^ (output[j-9]) ^ (ROTATE_LEFT((output[j-3]),15))) ^ 
		(ROTATE_LEFT((output[j-13]),7)) ^ (output[j-6]);
    }*/
   //////////////////////////////////////////////////////////////////////////////////////////////////
	//��������߼�����𿪷ֲ�����
	//���� 2011��4��1��
    for(j = len; j < 68; j++)
	{
		uiTemp1 = ROTATE_LEFT(output[j-3],15);
        uiTemp2 = ROTATE_LEFT(output[j-13],7);
        output[j] = Substi_P1(output[j-len] ^ output[j-9] ^ uiTemp1) ^ uiTemp2 ^ output[j-6];
    }
	//////////////////////////////////////////////////////////////////////////////////////////////////
    for(i = 0; i < 64; i++){
        output1[i] = output[i] ^ output[i+4];
    }
}


/***************************************************************************
* Subroutine:	Encode
* Function:		Encodes input (UINT32) into output (UINT8). Assumes len is
	 a multiple of 4..
* Input:		None
* Output:		None;
* Description:	 
* Date:			2011.03. 
* ModifyRecord:
* *************************************************************************/ 
static void Encode(UINT8 *output,UINT32 *input,UINT32 len)
{
	UINT32 i, j;

	for(i = 0, j = len; j > 0; i++, j -= 4) {
		output[j-1] = (UINT8)(input[i] & 0xff);
		output[j-2] = (UINT8)((input[i] >> 8) & 0xff);
		output[j-3] = (UINT8)((input[i] >> 16) & 0xff);
		output[j-4] = (UINT8)((input[i] >> 24) & 0xff);
	}
}
 
/***************************************************************************
* Subroutine:	Decode
* Function:		Decodes input (UINT8) into output (UINT32). Assumes len is
	 a multiple of 4.
* Input:		None
* Output:		None;
* Description:	 
* Date:			2011.03. 
* ModifyRecord:
* *************************************************************************/ 
static void Decode(UINT32 *output,UINT8 *input,UINT32 len)
{
	UINT32 i, j;

	for(i = 0, j = 0; j < len; i++, j += 4)
		output[i] = (((UINT32)input[j]) << 24) | (((UINT32)input[j+1]) << 16) | 
                    (((UINT32)input[j+2]) << 8) | ((UINT32)input[j+3]);
}
