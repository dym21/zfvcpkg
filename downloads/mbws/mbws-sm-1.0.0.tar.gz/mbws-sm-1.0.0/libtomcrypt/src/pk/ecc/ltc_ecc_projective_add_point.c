/* LibTomCrypt, modular cryptographic library -- Tom St Denis
 *
 * LibTomCrypt is a library that provides various cryptographic
 * algorithms in a highly modular and flexible manner.
 *
 * The library is free for all purposes without any express
 * guarantee it works.
 *
 * Tom St Denis, tomstdenis@gmail.com, http://libtom.org
 */

/* Implements ECC over Z/pZ for curve y^2 = x^3 - 3x + b
 *
 * All curves taken from NIST recommendation paper of July 1999
 * Available at http://csrc.nist.gov/cryptval/dss.htm
 */
#include "tomcrypt.h"

/**
  @file ltc_ecc_projective_add_point.c
  ECC Crypto, Tom St Denis
*/  

#if defined(LTC_MECC) && (!defined(LTC_MECC_ACCEL) || defined(LTM_LTC_DESC))

/**
   Add two ECC points
   @param P        The point to add
   @param Q        The point to add
   @param R        [out] The destination of the double
   @param modulus  The modulus of the field the ECC curve is in
   @param mp       The "b" value from montgomery_setup()
   @return CRYPT_OK on success
*/

int ltc_ecc_projective_add_point(ecc_point *P, ecc_point *Q, ecc_point *R, void *modulus, void *mp)
{
   return ltc_ecc_projective_add_point_ex(P,Q,R,modulus,mp);
}

// int ltc_ecc_projective_add_point(ecc_point *P, ecc_point *Q, ecc_point *R, void *modulus, void *mp)
// {
//    void  *t1, *t2, *x, *y, *z;
//    int    err;
// 
//    LTC_ARGCHK(P       != NULL);
//    LTC_ARGCHK(Q       != NULL);
//    LTC_ARGCHK(R       != NULL);
//    LTC_ARGCHK(modulus != NULL);
//    LTC_ARGCHK(mp      != NULL);
// 
//    if ((err = mp_init_multi(&t1, &t2, &x, &y, &z, NULL)) != CRYPT_OK) {
//       return err;
//    }
//    
//    /* should we dbl instead? */
//    if ((err = mp_sub(modulus, Q->y, t1)) != CRYPT_OK)                          { goto done; }
// 
//    if ( (mp_cmp(P->x, Q->x) == LTC_MP_EQ) && 
//         (Q->z != NULL && mp_cmp(P->z, Q->z) == LTC_MP_EQ) &&
//         (mp_cmp(P->y, Q->y) == LTC_MP_EQ || mp_cmp(P->y, t1) == LTC_MP_EQ)) {
//         mp_clear_multi(t1, t2, x, y, z, NULL);
//         return ltc_ecc_projective_dbl_point(P, R, modulus, mp);
//    }
// 
//    if ((err = mp_copy(P->x, x)) != CRYPT_OK)                                   { goto done; }
//    if ((err = mp_copy(P->y, y)) != CRYPT_OK)                                   { goto done; }
//    if ((err = mp_copy(P->z, z)) != CRYPT_OK)                                   { goto done; }
// 
//    /* if Z is one then these are no-operations */
//    if (Q->z != NULL) {
//       /* T1 = Z' * Z' */
//       if ((err = mp_sqr(Q->z, t1)) != CRYPT_OK)                                { goto done; }
//       if ((err = mp_montgomery_reduce(t1, modulus, mp)) != CRYPT_OK)           { goto done; }
//       /* X = X * T1 */
//       if ((err = mp_mul(t1, x, x)) != CRYPT_OK)                                { goto done; }
//       if ((err = mp_montgomery_reduce(x, modulus, mp)) != CRYPT_OK)            { goto done; }
//       /* T1 = Z' * T1 */
//       if ((err = mp_mul(Q->z, t1, t1)) != CRYPT_OK)                            { goto done; }
//       if ((err = mp_montgomery_reduce(t1, modulus, mp)) != CRYPT_OK)           { goto done; }
//       /* Y = Y * T1 */
//       if ((err = mp_mul(t1, y, y)) != CRYPT_OK)                                { goto done; }
//       if ((err = mp_montgomery_reduce(y, modulus, mp)) != CRYPT_OK)            { goto done; }
//    }
// 
//    /* T1 = Z*Z */
//    if ((err = mp_sqr(z, t1)) != CRYPT_OK)                                      { goto done; }
//    if ((err = mp_montgomery_reduce(t1, modulus, mp)) != CRYPT_OK)              { goto done; }
//    /* T2 = X' * T1 */
//    if ((err = mp_mul(Q->x, t1, t2)) != CRYPT_OK)                               { goto done; }
//    if ((err = mp_montgomery_reduce(t2, modulus, mp)) != CRYPT_OK)              { goto done; }
//    /* T1 = Z * T1 */
//    if ((err = mp_mul(z, t1, t1)) != CRYPT_OK)                                  { goto done; }
//    if ((err = mp_montgomery_reduce(t1, modulus, mp)) != CRYPT_OK)              { goto done; }
//    /* T1 = Y' * T1 */
//    if ((err = mp_mul(Q->y, t1, t1)) != CRYPT_OK)                               { goto done; }
//    if ((err = mp_montgomery_reduce(t1, modulus, mp)) != CRYPT_OK)              { goto done; }
// 
//    /* Y = Y - T1 */
//    if ((err = mp_sub(y, t1, y)) != CRYPT_OK)                                   { goto done; }
//    if (mp_cmp_d(y, 0) == LTC_MP_LT) {
//       if ((err = mp_add(y, modulus, y)) != CRYPT_OK)                           { goto done; }
//    }
//    /* T1 = 2T1 */
//    if ((err = mp_add(t1, t1, t1)) != CRYPT_OK)                                 { goto done; }
//    if (mp_cmp(t1, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(t1, modulus, t1)) != CRYPT_OK)                         { goto done; }
//    }
//    /* T1 = Y + T1 */
//    if ((err = mp_add(t1, y, t1)) != CRYPT_OK)                                  { goto done; }
//    if (mp_cmp(t1, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(t1, modulus, t1)) != CRYPT_OK)                         { goto done; }
//    }
//    /* X = X - T2 */
//    if ((err = mp_sub(x, t2, x)) != CRYPT_OK)                                   { goto done; }
//    if (mp_cmp_d(x, 0) == LTC_MP_LT) {
//       if ((err = mp_add(x, modulus, x)) != CRYPT_OK)                           { goto done; }
//    }
//    /* T2 = 2T2 */
//    if ((err = mp_add(t2, t2, t2)) != CRYPT_OK)                                 { goto done; }
//    if (mp_cmp(t2, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(t2, modulus, t2)) != CRYPT_OK)                         { goto done; }
//    }
//    /* T2 = X + T2 */
//    if ((err = mp_add(t2, x, t2)) != CRYPT_OK)                                  { goto done; }
//    if (mp_cmp(t2, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(t2, modulus, t2)) != CRYPT_OK)                         { goto done; }
//    }
// 
//    /* if Z' != 1 */
//    if (Q->z != NULL) {
//       /* Z = Z * Z' */
//       if ((err = mp_mul(z, Q->z, z)) != CRYPT_OK)                              { goto done; }
//       if ((err = mp_montgomery_reduce(z, modulus, mp)) != CRYPT_OK)            { goto done; }
//    }
// 
//    /* Z = Z * X */
//    if ((err = mp_mul(z, x, z)) != CRYPT_OK)                                    { goto done; }
//    if ((err = mp_montgomery_reduce(z, modulus, mp)) != CRYPT_OK)               { goto done; }
// 
//    /* T1 = T1 * X  */
//    if ((err = mp_mul(t1, x, t1)) != CRYPT_OK)                                  { goto done; }
//    if ((err = mp_montgomery_reduce(t1, modulus, mp)) != CRYPT_OK)              { goto done; }
//    /* X = X * X */
//    if ((err = mp_sqr(x, x)) != CRYPT_OK)                                       { goto done; }
//    if ((err = mp_montgomery_reduce(x, modulus, mp)) != CRYPT_OK)               { goto done; }
//    /* T2 = T2 * x */
//    if ((err = mp_mul(t2, x, t2)) != CRYPT_OK)                                  { goto done; }
//    if ((err = mp_montgomery_reduce(t2, modulus, mp)) != CRYPT_OK)              { goto done; }
//    /* T1 = T1 * X  */
//    if ((err = mp_mul(t1, x, t1)) != CRYPT_OK)                                  { goto done; }
//    if ((err = mp_montgomery_reduce(t1, modulus, mp)) != CRYPT_OK)              { goto done; }
//  
//    /* X = Y*Y */
//    if ((err = mp_sqr(y, x)) != CRYPT_OK)                                       { goto done; }
//    if ((err = mp_montgomery_reduce(x, modulus, mp)) != CRYPT_OK)               { goto done; }
//    /* X = X - T2 */
//    if ((err = mp_sub(x, t2, x)) != CRYPT_OK)                                   { goto done; }
//    if (mp_cmp_d(x, 0) == LTC_MP_LT) {
//       if ((err = mp_add(x, modulus, x)) != CRYPT_OK)                           { goto done; }
//    }
// 
//    /* T2 = T2 - X */
//    if ((err = mp_sub(t2, x, t2)) != CRYPT_OK)                                  { goto done; }
//    if (mp_cmp_d(t2, 0) == LTC_MP_LT) {
//       if ((err = mp_add(t2, modulus, t2)) != CRYPT_OK)                         { goto done; }
//    } 
//    /* T2 = T2 - X */
//    if ((err = mp_sub(t2, x, t2)) != CRYPT_OK)                                  { goto done; }
//    if (mp_cmp_d(t2, 0) == LTC_MP_LT) {
//       if ((err = mp_add(t2, modulus, t2)) != CRYPT_OK)                         { goto done; }
//    }
//    /* T2 = T2 * Y */
//    if ((err = mp_mul(t2, y, t2)) != CRYPT_OK)                                  { goto done; }
//    if ((err = mp_montgomery_reduce(t2, modulus, mp)) != CRYPT_OK)              { goto done; }
//    /* Y = T2 - T1 */
//    if ((err = mp_sub(t2, t1, y)) != CRYPT_OK)                                  { goto done; }
//    if (mp_cmp_d(y, 0) == LTC_MP_LT) {
//       if ((err = mp_add(y, modulus, y)) != CRYPT_OK)                           { goto done; }
//    }
//    /* Y = Y/2 */
//    if (mp_isodd(y)) {
//       if ((err = mp_add(y, modulus, y)) != CRYPT_OK)                           { goto done; }
//    }
//    if ((err = mp_div_2(y, y)) != CRYPT_OK)                                     { goto done; }
// 
//    if ((err = mp_copy(x, R->x)) != CRYPT_OK)                                   { goto done; }
//    if ((err = mp_copy(y, R->y)) != CRYPT_OK)                                   { goto done; }
//    if ((err = mp_copy(z, R->z)) != CRYPT_OK)                                   { goto done; }
// 
//    err = CRYPT_OK;
// done:
//    mp_clear_multi(t1, t2, x, y, z, NULL);
//    return err;
// }


/**
��дECC������㣬ʹ��֧��
y^2 = x^3 + ax + b ����
����ʵ����Jacobian������Ӱ����ϵ
P(X1,Y1,Z1) + Q(X2,Y2,Z2) = R(X3,Y3,Z3)  ����֮��Ĺ�ϵ��
T1 = X1*Z2^2 
T2 = X2*Z1^2
T3 = T1 - T2
T4 = Y1*Z2^3
T5 = Y2*Z1^3
T6 = T4 - T5
T7 = T1 + T2
T8 = T4 + T5
X3 = T6^2 - T7*T3^2
T9 = T7*T3^2 - 2*X3
Y3 = (T9*T6 - T8*T3^3)/2
Z3 = Z1*Z2*T3
���ߣ����� 2011��4��7��
*/
int ltc_ecc_projective_add_point_ex(ecc_point *P, ecc_point *Q, ecc_point *R, void *modulus,void *mp)
{
   void *X1, *Y1, *Z1;
   void *X2, *Y2, *Z2;
   void *X3, *Y3, *Z3;
   void *T1, *T2, *T3, *T4, *T5, *T6, *T7, *T8, *T9, *T10, *T11, *T12;
   void *t1;
   int    err;

   LTC_ARGCHK(P       != NULL);
   LTC_ARGCHK(Q       != NULL);
   LTC_ARGCHK(R       != NULL);
   LTC_ARGCHK(modulus != NULL);
   LTC_ARGCHK(mp      != NULL);

   if ((err = mp_init_multi(&T1, &T2, &T3, &T4, &T5, &T6,
	                        &T7, &T8, &T9, &T10, &T11, &T12,
							&X1, &Y1, &Z1, 
							&X2, &Y2, &Z2,
							&X3, &Y3, &Z3,
							&t1,
							NULL)) != CRYPT_OK) 
   {
      return err;
   }
   
   /* should we dbl instead? */
   if ((err = mp_sub(modulus, Q->y, t1)) != CRYPT_OK)                          { goto done; }

   if ( (mp_cmp(P->x, Q->x) == LTC_MP_EQ) && 
        (Q->z != NULL && mp_cmp(P->z, Q->z) == LTC_MP_EQ) &&
        (mp_cmp(P->y, Q->y) == LTC_MP_EQ || mp_cmp(P->y, t1) == LTC_MP_EQ))
   {
	   mp_clear_multi(T1, T2, T3, T4, T5, T6,
		              T7, T8, T9, T10, T11, T12,
		              X1, Y1, Z1,
		              X2, Y2, Z2,
		              X3, Y3, Z3,t1,NULL);
        return ltc_ecc_projective_dbl_point(P, R, modulus, mp);
   }
   //��P�㸴��P(X1,Y1,Z1)
   if ((err = mp_copy(P->x, X1)) != CRYPT_OK)                                   { goto done; }
   if ((err = mp_copy(P->y, Y1)) != CRYPT_OK)                                   { goto done; }
   if ((err = mp_copy(P->z, Z1)) != CRYPT_OK)                                   { goto done; }
   //��Q�㸴��Q(X2,Y2,Z2)
   if ((err = mp_copy(Q->x, X2)) != CRYPT_OK)                                   { goto done; }
   if ((err = mp_copy(Q->y, Y2)) != CRYPT_OK)                                   { goto done; }
   if ((err = mp_copy(Q->z, Z2)) != CRYPT_OK)                                   { goto done; }

   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������ T1 = X1*Z2^2 
   /* T1 = Z2*Z2 = Z2^2  */
   if ((err = mp_sqr(Z2, T1)) != CRYPT_OK)                                  { goto done; }
   if ((err = mp_mod(T1, modulus,T1)) != CRYPT_OK)                          { goto done; }
   /* T1 = X1 * T1 = X1*Z2^2   */
   if ((err = mp_mul(X1, T1, T1)) != CRYPT_OK)                              { goto done; }
   if ((err = mp_mod(T1, modulus,T1)) != CRYPT_OK)                          { goto done; }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������ T2 = X2*Z1^2
   /* T2 = Z1*Z1 = Z1^2  */
   if ((err = mp_sqr(Z1, T2)) != CRYPT_OK)                                  { goto done; }
   if ((err = mp_mod(T2, modulus,T2)) != CRYPT_OK)                          { goto done; }
   /* T2 = X2 * T2 = X2*Z1^2   */   //������ ��X2 ���� X1 �������Ӻü���
   if ((err = mp_mul(X2, T2, T2)) != CRYPT_OK)                              { goto done; }
   if ((err = mp_mod(T2, modulus,T2)) != CRYPT_OK)                          { goto done; } 
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������ T3 = T1 - T2
   if ((err = mp_sub(T1, T2, T3)) != CRYPT_OK)                                 { goto done; }
   if (mp_cmp_d(T3, 0) == LTC_MP_LT)
   {
      if ((err = mp_add(T3, modulus, T3)) != CRYPT_OK)                         { goto done; }
   }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������ T4 = Y1*Z2^3
   /* T4 = Z2^2 */
   if ((err = mp_sqr(Z2, T4)) != CRYPT_OK)                                  { goto done; }
   if ((err = mp_mod(T4, modulus,T4)) != CRYPT_OK)                          { goto done; }
   /* T4 = Z2^3 */
   if ((err = mp_mul(Z2, T4, T4)) != CRYPT_OK)                              { goto done; }
   if ((err = mp_mod(T4, modulus,T4)) != CRYPT_OK)                          { goto done; }
   /* T4 = Y1*Z2^3 */
   if ((err = mp_mul(Y1, T4, T4)) != CRYPT_OK)                              { goto done; }
   if ((err = mp_mod(T4, modulus,T4)) != CRYPT_OK)                          { goto done; }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  T5 = Y2*Z1^3
   /* T5 = Z1^2 */
   if ((err = mp_sqr(Z1, T5)) != CRYPT_OK)                                  { goto done; }
   if ((err = mp_mod(T5, modulus,T5)) != CRYPT_OK)                          { goto done; }
   /* T5 = Z1^3 */
   if ((err = mp_mul(Z1, T5, T5)) != CRYPT_OK)                              { goto done; }
   if ((err = mp_mod(T5, modulus,T5)) != CRYPT_OK)                          { goto done; }
   /* T5 = Y2*Z1^3 */
   if ((err = mp_mul(Y2, T5, T5)) != CRYPT_OK)                              { goto done; }
   if ((err = mp_mod(T5, modulus,T5)) != CRYPT_OK)                          { goto done; }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  T6 = T4 - T5
   if ((err = mp_sub(T4, T5, T6)) != CRYPT_OK)                                 { goto done; }
   if (mp_cmp_d(T6, 0) == LTC_MP_LT)
   {
      if ((err = mp_add(T6, modulus, T6)) != CRYPT_OK)                         { goto done; }
   }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  T7 = T1 + T2
   if ((err = mp_add(T1, T2, T7)) != CRYPT_OK)                                 { goto done; }
   if (mp_cmp(T7, modulus) != LTC_MP_LT)
   {
	   if ((err = mp_sub(T7, modulus, T7)) != CRYPT_OK)                        { goto done; }
   }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  T8 = T4 + T5
   if ((err = mp_add(T4, T5, T8)) != CRYPT_OK)                                 { goto done; }
   if (mp_cmp(T8, modulus) != LTC_MP_LT)
   {
	   if ((err = mp_sub(T8, modulus, T8)) != CRYPT_OK)                        { goto done; }
   }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  X3 = T6^2 - T7*T3^2
   /* T9 = T6^2 */
   if ((err = mp_sqr(T6, T9)) != CRYPT_OK)                                  { goto done; }
   if ((err = mp_mod(T9, modulus,T9)) != CRYPT_OK)                          { goto done; }
   /* T10 = T3^2 */
   if ((err = mp_sqr(T3, T10)) != CRYPT_OK)                                 { goto done; }
   if ((err = mp_mod(T10, modulus,T10)) != CRYPT_OK)                        { goto done; }
   /* T11 = T7*T3^2 */
   if ((err = mp_mul(T7, T10,T11)) != CRYPT_OK)                             { goto done; }
   if ((err = mp_mod(T11, modulus,T11)) != CRYPT_OK)                        { goto done; }
   /* X3 = T6^2 - T7*T3^2 */
   if ((err = mp_sub(T9, T11, X3)) != CRYPT_OK)                              { goto done; }
   if (mp_cmp_d(X3, 0) == LTC_MP_LT)
   {
      if ((err = mp_add(X3, modulus, X3)) != CRYPT_OK)                         { goto done; }
   }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  T9 = T7*T3^2 - 2*X3
   /* T9  = T7*T3^2 -X3 */
   if ((err = mp_sub(T11, X3, T9)) != CRYPT_OK)                              { goto done; }
   if (mp_cmp_d(T9, 0) == LTC_MP_LT)
   {
      if ((err = mp_add(T9, modulus, T9)) != CRYPT_OK)                       { goto done; }
   }
   /* T9  = T9 -X3 */
   if ((err = mp_sub(T9, X3, T9)) != CRYPT_OK)                               { goto done; }
   if (mp_cmp_d(T9, 0) == LTC_MP_LT)
   {
      if ((err = mp_add(T9, modulus, T9)) != CRYPT_OK)                       { goto done; }
   }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  Y3 = (T9*T6 - T8*T3^3)/2
    /* T12 = T9*T6 */
   if ((err = mp_mul(T9, T6,T12)) != CRYPT_OK)                             { goto done; }
   if ((err = mp_mod(T12, modulus,T12)) != CRYPT_OK)                        { goto done; }  

   /* T10 = T3^3 */
   if ((err = mp_mul(T3, T10,T10)) != CRYPT_OK)                             { goto done; }
   if ((err = mp_mod(T10, modulus,T10)) != CRYPT_OK)                        { goto done; }
    
   /* T10 = T8*T3^3 */
   if ((err = mp_mul(T8, T10,T10)) != CRYPT_OK)                             { goto done; }
   if ((err = mp_mod(T10, modulus,T10)) != CRYPT_OK)                        { goto done; }
   /*Y3 = T12 - T10 = T9*T6 - T8*T3^3 */
   if ((err = mp_sub(T12, T10, Y3)) != CRYPT_OK)                            { goto done; }
   if (mp_cmp_d(Y3, 0) == LTC_MP_LT)
   {
      if ((err = mp_add(Y3, modulus, Y3)) != CRYPT_OK)                      { goto done; }
   }
   /* Y3 = Y3/2 */
   if (mp_isodd(Y3)) {
	   if ((err = mp_add(Y3, modulus,Y3)) != CRYPT_OK)                      { goto done; }
   }
   if ((err = mp_div_2(Y3, Y3)) != CRYPT_OK)                                { goto done; }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  Z3 = Z1*Z2*T3
   /* Z3 = Z1*Z2 */
   if ((err = mp_mul(Z1, Z2,Z3)) != CRYPT_OK)                             { goto done; }
   if ((err = mp_mod(Z3, modulus,Z3)) != CRYPT_OK)                        { goto done; }
   /* Z3 = Z3*T3 = Z1*Z2*T3 */
   if ((err = mp_mul(Z3, T3,Z3)) != CRYPT_OK)                             { goto done; }
   if ((err = mp_mod(Z3, modulus,Z3)) != CRYPT_OK)                        { goto done; }
   ////////////////////////////////////////////////////////////////////////////////////////////
   //�����������Ƶ�R����
   if ((err = mp_copy(X3, R->x)) != CRYPT_OK)                                   { goto done; }
   if ((err = mp_copy(Y3, R->y)) != CRYPT_OK)                                   { goto done; }
   if ((err = mp_copy(Z3, R->z)) != CRYPT_OK)                                   { goto done; }
   /////////////////////////////////////////////////////////////////////////////////////////////
   err = CRYPT_OK;
done:
   mp_clear_multi(T1, T2, T3, T4, T5, T6,
	   T7, T8, T9, T10, T11, T12,
	   X1, Y1, Z1,
	   X2, Y2, Z2,
	   X3, Y3, Z3,t1,NULL);
   return err;
}

#endif

/* $Source: /cvs/libtom/libtomcrypt/src/pk/ecc/ltc_ecc_projective_add_point.c,v $ */
/* $Revision: 1.16 $ */
/* $Date: 2007/05/12 14:32:35 $ */

