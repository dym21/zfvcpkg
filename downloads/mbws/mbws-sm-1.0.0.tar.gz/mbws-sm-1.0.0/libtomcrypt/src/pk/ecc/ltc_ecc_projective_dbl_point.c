/* LibTomCrypt, modular cryptographic library -- Tom St Denis
 *
 * LibTomCrypt is a library that provides various cryptographic
 * algorithms in a highly modular and flexible manner.
 *
 * The library is free for all purposes without any express
 * guarantee it works.
 *
 * Tom St Denis, tomstdenis@gmail.com, http://libtom.org
 */

/* Implements ECC over Z/pZ for curve y^2 = x^3 - 3x + b
 *
 * All curves taken from NIST recommendation paper of July 1999
 * Available at http://csrc.nist.gov/cryptval/dss.htm
 */
#include "tomcrypt.h"

/**
  @file ltc_ecc_projective_dbl_point.c
  ECC Crypto, Tom St Denis
*/  


#if defined(LTC_MECC) && (!defined(LTC_MECC_ACCEL) || defined(LTM_LTC_DESC))

/**
   Double an ECC point
   @param P   The point to double
   @param R   [out] The destination of the double
   @param modulus  The modulus of the field the ECC curve is in
   @param mp       The "b" value from montgomery_setup()
   @return CRYPT_OK on success
*/

/*
�Ա�׼���б���������и��죬ʹ��֧��
y^2 = x^3 + ax + b �������� 
ʵ����Jacobian������Ӱ����ϵ
���� 2011��4��6��
*/
int ltc_ecc_projective_dbl_point(ecc_point *P, ecc_point *R, void *modulus, void *mp)
{
	void *A=NULL;
	int   err=0,x=0,keysize=0;
	
	//��ȡ��Կ��С�����ֽڱ�ʾ
	keysize = mp_unsigned_bin_size(modulus);
	/* find key size */
	for (x = 0; (keysize > ltc_ecc_sets[x].size) && (ltc_ecc_sets[x].size != 0); x++);
	keysize = ltc_ecc_sets[x].size;
	if (keysize > ECC_MAXSIZE || ltc_ecc_sets[x].size == 0) 
	{
		return CRYPT_INVALID_KEYSIZE;
	} 
	if ((err = mp_init_multi(&A, NULL)) != CRYPT_OK)                             { goto done; }   
	if ((err = mp_read_radix(A,ltc_ecc_sets[x].A, 16)) != CRYPT_OK)              { goto done; }  
    
	if ((err = ltc_ecc_projective_dbl_point_ex(P,R,modulus,mp,A)) != CRYPT_OK)   { goto done; }               
done:
	mp_clear_multi(A, NULL);
    return err;
}

// int ltc_ecc_projective_dbl_point(ecc_point *P, ecc_point *R, void *modulus, void *mp)
// {
//    void *t1, *t2;
//    int   err;
// 
//    LTC_ARGCHK(P       != NULL);
//    LTC_ARGCHK(R       != NULL);
//    LTC_ARGCHK(modulus != NULL);
//    LTC_ARGCHK(mp      != NULL);
// 
//    if ((err = mp_init_multi(&t1, &t2, NULL)) != CRYPT_OK)
//    {
//       return err;
//    }
// 
//    if (P != R) 
//    {
//       if ((err = mp_copy(P->x, R->x)) != CRYPT_OK)                                { goto done; }
//       if ((err = mp_copy(P->y, R->y)) != CRYPT_OK)                                { goto done; }
//       if ((err = mp_copy(P->z, R->z)) != CRYPT_OK)                                { goto done; }
//    }
// 
//    /* t1 = Z * Z */
//    if ((err = mp_sqr(R->z, t1)) != CRYPT_OK)                                      { goto done; }
//    if ((err = mp_montgomery_reduce(t1, modulus, mp)) != CRYPT_OK)                 { goto done; }
//    /* Z = Y * Z */
//    if ((err = mp_mul(R->z, R->y, R->z)) != CRYPT_OK)                              { goto done; }
//    if ((err = mp_montgomery_reduce(R->z, modulus, mp)) != CRYPT_OK)               { goto done; }
//    /* Z = 2Z */
//    if ((err = mp_add(R->z, R->z, R->z)) != CRYPT_OK)                              { goto done; }
//    if (mp_cmp(R->z, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(R->z, modulus, R->z)) != CRYPT_OK)                        { goto done; }
//    }
//    
//    /* T2 = X - T1 */
//    if ((err = mp_sub(R->x, t1, t2)) != CRYPT_OK)                                  { goto done; }
//    if (mp_cmp_d(t2, 0) == LTC_MP_LT) {
//       if ((err = mp_add(t2, modulus, t2)) != CRYPT_OK)                            { goto done; }
//    }
//    /* T1 = X + T1 */
//    if ((err = mp_add(t1, R->x, t1)) != CRYPT_OK)                                  { goto done; }
//    if (mp_cmp(t1, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(t1, modulus, t1)) != CRYPT_OK)                            { goto done; }
//    }
//    /* T2 = T1 * T2 */
//    if ((err = mp_mul(t1, t2, t2)) != CRYPT_OK)                                    { goto done; }
//    if ((err = mp_montgomery_reduce(t2, modulus, mp)) != CRYPT_OK)                 { goto done; }
//    /* T1 = 2T2 */
//    if ((err = mp_add(t2, t2, t1)) != CRYPT_OK)                                    { goto done; }
//    if (mp_cmp(t1, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(t1, modulus, t1)) != CRYPT_OK)                            { goto done; }
//    }
//    /* T1 = T1 + T2 */
//    if ((err = mp_add(t1, t2, t1)) != CRYPT_OK)                                    { goto done; }
//    if (mp_cmp(t1, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(t1, modulus, t1)) != CRYPT_OK)                            { goto done; }
//    }
// 
//    /* Y = 2Y */
//    if ((err = mp_add(R->y, R->y, R->y)) != CRYPT_OK)                              { goto done; }
//    if (mp_cmp(R->y, modulus) != LTC_MP_LT) {
//       if ((err = mp_sub(R->y, modulus, R->y)) != CRYPT_OK)                        { goto done; }
//    }
//    /* Y = Y * Y */
//    if ((err = mp_sqr(R->y, R->y)) != CRYPT_OK)                                    { goto done; }
//    if ((err = mp_montgomery_reduce(R->y, modulus, mp)) != CRYPT_OK)               { goto done; }
//    /* T2 = Y * Y */
//    if ((err = mp_sqr(R->y, t2)) != CRYPT_OK)                                      { goto done; }
//    if ((err = mp_montgomery_reduce(t2, modulus, mp)) != CRYPT_OK)                 { goto done; }
//    /* T2 = T2/2 */
//    if (mp_isodd(t2)) {
//       if ((err = mp_add(t2, modulus, t2)) != CRYPT_OK)                            { goto done; }
//    }
//    if ((err = mp_div_2(t2, t2)) != CRYPT_OK)                                      { goto done; }
//    /* Y = Y * X */
//    if ((err = mp_mul(R->y, R->x, R->y)) != CRYPT_OK)                              { goto done; }
//    if ((err = mp_montgomery_reduce(R->y, modulus, mp)) != CRYPT_OK)               { goto done; }
// 
//    /* X  = T1 * T1 */
//    if ((err = mp_sqr(t1, R->x)) != CRYPT_OK)                                      { goto done; }
//    if ((err = mp_montgomery_reduce(R->x, modulus, mp)) != CRYPT_OK)               { goto done; }
//    /* X = X - Y */
//    if ((err = mp_sub(R->x, R->y, R->x)) != CRYPT_OK)                              { goto done; }
//    if (mp_cmp_d(R->x, 0) == LTC_MP_LT) {
//       if ((err = mp_add(R->x, modulus, R->x)) != CRYPT_OK)                        { goto done; }
//    }
//    /* X = X - Y */
//    if ((err = mp_sub(R->x, R->y, R->x)) != CRYPT_OK)                              { goto done; }
//    if (mp_cmp_d(R->x, 0) == LTC_MP_LT) {
//       if ((err = mp_add(R->x, modulus, R->x)) != CRYPT_OK)                        { goto done; }
//    }
// 
//    /* Y = Y - X */     
//    if ((err = mp_sub(R->y, R->x, R->y)) != CRYPT_OK)                              { goto done; }
//    if (mp_cmp_d(R->y, 0) == LTC_MP_LT) {
//       if ((err = mp_add(R->y, modulus, R->y)) != CRYPT_OK)                        { goto done; }
//    }
//    /* Y = Y * T1 */
//    if ((err = mp_mul(R->y, t1, R->y)) != CRYPT_OK)                                { goto done; }
//    if ((err = mp_montgomery_reduce(R->y, modulus, mp)) != CRYPT_OK)               { goto done; }
//    /* Y = Y - T2 */
//    if ((err = mp_sub(R->y, t2, R->y)) != CRYPT_OK)                                { goto done; }
//    if (mp_cmp_d(R->y, 0) == LTC_MP_LT) {
//       if ((err = mp_add(R->y, modulus, R->y)) != CRYPT_OK)                        { goto done; }
//    }
//  
//    err = CRYPT_OK;
// done:
//    mp_clear_multi(t1, t2, NULL);
//    return err;
// }


/**
��ECC����������и���֧�֣�ʹ��֧��
y^2 = x^3 + ax + b �������� 
ʵ����Jacobian������Ӱ����ϵ
2P(X1,Y1,Z1)=R(X2,Y2,Z2)  ����֮��Ĺ�ϵ��
T1 = 3*X1^2 + a*Z1^4
T2 = 4*X1*Y1^2
T3 = 8*Y1^4
X2 = T1^2 - 2*T2
Y2 = T1*(T2 - X2)-T3
Z2 = 2*Y1*Z1
���ߣ����� 2011��3��31��
*/
/**
   Double an ECC point
   @param P   The point to double
   @param R   [out] The destination of the double
   @param modulus  The modulus of the field the ECC curve is in
   @param mp       The "b" value from montgomery_setup()
   @param A   �����е�A����
   @return CRYPT_OK on success
*/
int ltc_ecc_projective_dbl_point_ex(ecc_point *P, ecc_point *R, void *modulus,void *mp,void *A)
{
   void *t1,*t2,*t3,*t4;
   int   err;
   void *T1,*T2,*T3;
   LTC_ARGCHK(P       != NULL);
   LTC_ARGCHK(R       != NULL);
   LTC_ARGCHK(modulus != NULL);
   LTC_ARGCHK(mp      != NULL);
   LTC_ARGCHK(A       != NULL);
   if (err = mp_init_multi(&T1,&T2,&T3,&t1,&t2,&t3,&t4,NULL)!=CRYPT_OK)
   {
	   return err;
   }
   if (P != R)
   {
      if ((err = mp_copy(P->x, R->x)) != CRYPT_OK)                                { goto done; }
      if ((err = mp_copy(P->y, R->y)) != CRYPT_OK)                                { goto done; }
      if ((err = mp_copy(P->z, R->z)) != CRYPT_OK)                                { goto done; }
   }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���� Z1^2  �ڱ��� t1 = Z1^2 ��
   /* t1 = Z * Z */
   if ((err = mp_sqr(R->z, t1)) != CRYPT_OK)                                      { goto done; }
   if ((err = mp_mod(t1, modulus,t1)) != CRYPT_OK)                                { goto done; }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������ Z2 = 2Y1Z1
   /* Z = Y * Z */
   if ((err = mp_mul(R->z, R->y, R->z)) != CRYPT_OK)                              { goto done; }
   if ((err = mp_mod(R->z, modulus,R->z)) != CRYPT_OK)                            { goto done; }
   /* Z = 2Z */
   if ((err = mp_add(R->z, R->z, R->z)) != CRYPT_OK)                              { goto done; }
   if (mp_cmp(R->z, modulus) != LTC_MP_LT) {
      if ((err = mp_sub(R->z, modulus, R->z)) != CRYPT_OK)                        { goto done; }
   }
   //���ϲ������  Z2 = 2Y1Z1
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  T1 = 3X1^2 + aZ1^4
   /* ���� t4 = X1^2 */
   if ((err = mp_mul(R->x,R->x,t4)) != CRYPT_OK)                                  { goto done; }
   if ((err = mp_mod(t4, modulus,t4)) != CRYPT_OK)                                { goto done; }

   /* t3 = 2t4 */
   if ((err = mp_add(t4, t4, t3)) != CRYPT_OK)                                    { goto done; }
   if (mp_cmp(t3, modulus) != LTC_MP_LT) {
	   if ((err = mp_sub(t3, modulus, t3)) != CRYPT_OK)                           { goto done; }
   }


   /* t4 = 3t4 =3X1^2  */
   if ((err = mp_add(t3, t4, t4)) != CRYPT_OK)                                    { goto done; }
   if (mp_cmp(t4, modulus) != LTC_MP_LT) {
	   if ((err = mp_sub(t4, modulus, t4)) != CRYPT_OK)                           { goto done; }
   }

   /*  ���� t1 = Z1^2 * Z1^2 = Z1^4 */
   if ((err = mp_sqr(t1, t1)) != CRYPT_OK)                                        { goto done; }
   if ((err = mp_mod(t1, modulus,t1)) != CRYPT_OK)                                { goto done; }

   /*  ���� t1 = a * Z1^4 */
   if ((err = mp_mul(A,t1,t1)) != CRYPT_OK)                                       { goto done; }
   if ((err = mp_mod(t1, modulus,t1)) != CRYPT_OK)                                { goto done; }
   /*  ���� T1 = t4 + t1 = 3X1^2 + aZ1^4 */
   if ((err = mp_add(t4, t1, T1)) != CRYPT_OK)                                    { goto done; }
   if (mp_cmp(T1, modulus) != LTC_MP_LT)
   {
	   if ((err = mp_sub(T1, modulus, T1)) != CRYPT_OK)                           { goto done; }
   }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������ T3 = 8Y1^4
   /* Y = 2Y */
   if ((err = mp_add(R->y, R->y, R->y)) != CRYPT_OK)                              { goto done; }
   if (mp_cmp(R->y, modulus) != LTC_MP_LT) {
      if ((err = mp_sub(R->y, modulus, R->y)) != CRYPT_OK)                        { goto done; }
   }
   /* Y = Y * Y  = 4Y1^2  */
   if ((err = mp_sqr(R->y, R->y)) != CRYPT_OK)                                    { goto done; }
   if ((err = mp_mod(R->y, modulus,R->y)) != CRYPT_OK)                            { goto done; }
   /* t2 = Y * Y  = 16Y1^4 */
   if ((err = mp_sqr(R->y, t2)) != CRYPT_OK)                                      { goto done; }
   if ((err = mp_mod(t2, modulus,t2)) != CRYPT_OK)                                { goto done; }
   /* t2 = t2/2 */
   if (mp_isodd(t2)) {
      if ((err = mp_add(t2, modulus, t2)) != CRYPT_OK)                            { goto done; }
   }
   if ((err = mp_div_2(t2, T3)) != CRYPT_OK)                                      { goto done; }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������ T2 = 4X1Y1^2 
   /* Y = Y * X = 4Y1^2 * X1 = T2 */
   if ((err = mp_mul(R->y, R->x, T2)) != CRYPT_OK)                                { goto done; }
   if ((err = mp_mod(T2, modulus,T2)) != CRYPT_OK)                                { goto done; }
   /////////////////////////////////////////////////////////////////////////////////////////////
   //���²������  X2 = T1^2 - 2T2
   /* X  = T1 * T1 */
   if ((err = mp_sqr(T1, R->x)) != CRYPT_OK)                                      { goto done; }
   if ((err = mp_mod(R->x, modulus,R->x)) != CRYPT_OK)                            { goto done; }
   /* X = X - T2 */
   if ((err = mp_sub(R->x, T2, R->x)) != CRYPT_OK)                                { goto done; }
   if (mp_cmp_d(R->x, 0) == LTC_MP_LT) {
      if ((err = mp_add(R->x, modulus, R->x)) != CRYPT_OK)                        { goto done; }
   }
   /* X = X - T2 */
   if ((err = mp_sub(R->x, T2, R->x)) != CRYPT_OK)                                { goto done; }
   if (mp_cmp_d(R->x, 0) == LTC_MP_LT) {
      if ((err = mp_add(R->x, modulus, R->x)) != CRYPT_OK)                        { goto done; }
   }
   ////////////////////////////////////////////////////////////////////////////////////////////
   //���²������ Y2 = T1(T2 - X2)-T3
   /* Y = Y - X */     
   if ((err = mp_sub(T2, R->x, R->y)) != CRYPT_OK)                                { goto done; }
   if (mp_cmp_d(R->y, 0) == LTC_MP_LT) {
      if ((err = mp_add(R->y, modulus, R->y)) != CRYPT_OK)                        { goto done; }
   }
   /* Y = Y * T1 */
   if ((err = mp_mul(R->y, T1, R->y)) != CRYPT_OK)                                { goto done; }
   if ((err = mp_mod(R->y, modulus,R->y)) != CRYPT_OK)                            { goto done; }

   /* Y = Y - T3 */
   if ((err = mp_sub(R->y, T3, R->y)) != CRYPT_OK)                                { goto done; }
   if (mp_cmp_d(R->y, 0) == LTC_MP_LT) {
      if ((err = mp_add(R->y, modulus, R->y)) != CRYPT_OK)                        { goto done; }
   }
   err = CRYPT_OK;
done:
   mp_clear_multi(T1,T2,T3,t1,t2,t3,t4,NULL);
   return err;
}
#endif
/* $Source: /cvs/libtom/libtomcrypt/src/pk/ecc/ltc_ecc_projective_dbl_point.c,v $ */
/* $Revision: 1.11 $ */
/* $Date: 2007/05/12 14:32:35 $ */

